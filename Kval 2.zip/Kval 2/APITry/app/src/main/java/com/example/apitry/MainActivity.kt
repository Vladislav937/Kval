package com.example.apitry

import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.URL
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button.setOnClickListener {
            val sPref = getPreferences(Context.MODE_PRIVATE)
            val savedText = sPref.getString(q1.text.toString()+q2.text.toString()+q3.text.toString(), "")
            if (savedText!="")
            {
                result.text = savedText
            }
            else
            {
            val retrofit = ApiService.create()
            val service = retrofit.search(q1.text.toString(),q2.text.toString(),q3.text.toString(),)
            service.enqueue(object : Callback<Request> {

                override fun onResponse(call: Call<Request>, response: Response<Request>) {
                    if (response.isSuccessful)
                    {
                        println(response.body())
                    val m = response.body()
                    result.text = m?.name!!.date[0].
                    val ed = sPref.edit()
                    ed.putString("${q1.text}${q2.text}${q3.text}", "${result.text}")
                    ed.apply()
                    }
                    else
                    {
                        result.text = "Ошибка при введении данных"
                    }
                }

                override fun onFailure(call: Call<Request>, t: Throwable) {
                    result.text ="Ошибка при подключении к серверу"
                }
            })
        }
        }
    }

    override fun onPause() {
        super.onPause()
        val sPref = getPreferences(Context.MODE_PRIVATE)
        val ed = sPref.edit()
        ed.putString("last1","${q1.text}")
        ed.putString("last2","${q2.text}")
        ed.putString("last3","${q3.text}")

        ed.apply()
    }

    override fun onResume() {
        super.onResume()
        val sPref = getPreferences(Context.MODE_PRIVATE)
        val savedText1 = sPref.getString("last1", "")
        val savedText2 = sPref.getString("last2", "")
        val savedText3 = sPref.getString("last3", "")
        if (savedText1!="" && savedText2!="" && savedText3!="")
        {
            result.text = sPref.getString(savedText1+savedText2,"")
            q1.setText(savedText1)
            q2.setText(savedText2)
            q3.setText(savedText3)

        }
    }
}
