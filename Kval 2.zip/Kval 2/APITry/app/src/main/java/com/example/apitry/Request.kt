package com.example.apitry
data class Request(val Name:String)
{
    class Name(val Name:String, val Host Name:String)
    class CurTime(val Disc.Date:String)
    class Coord(val x:Float, val y:Float, val z:Float)
    class Any(val Date:String, val Mmax:Double)
}

data class Result (val total_count: Int, val incomplete_results: Boolean, val items: List<Request>)