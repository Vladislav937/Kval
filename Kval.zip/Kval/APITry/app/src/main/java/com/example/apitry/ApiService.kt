package com.example.apitry

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService
{
    @GET("https://astrocats.space/")
    //fun getRequest(): Call<Request>
    fun search(@Query("name") name:String, @Query("date") date:String, @Query("type") type:String)
    companion object Factory {
        fun create(): ApiService {
            val retrofit = Retrofit.Builder()
                //.addConverterFactory(JaxbConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://github.com/astrocatalogs/OACAPI")
                .build()

            return retrofit.create(ApiService::class.java);
        }
    }
}