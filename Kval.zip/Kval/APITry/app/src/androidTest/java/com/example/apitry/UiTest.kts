fun testChangeText_sameActivity (){

    OnView(withId(R.Id.editTextUserInput))
            .perform(typeText(String_to_be_typed),closeSoftKeyboard())
    OnView(withId(R.Id.changeTextButton)).
}